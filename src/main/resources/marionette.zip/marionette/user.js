user_pref("marionette.defaultPrefs.port", 0);
user_pref("browser.startup.homepage_override.mstone", "ignore");
user_pref("extensions.blocklist.enabled", false);
user_pref("extensions.blocklist.url", "");
user_pref("extensions.blocklist.detailsURL", "");
user_pref("security.sandbox.content.level", 0);
user_pref("media.gmp-gmpopenh264.enabled", false);
user_pref("media.gmp-manager.url", "http://localhost:8008");
